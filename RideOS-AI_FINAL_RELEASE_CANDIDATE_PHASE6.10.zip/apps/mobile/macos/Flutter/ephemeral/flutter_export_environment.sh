#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Users/hitanshughadai/development/flutter"
export "FLUTTER_APPLICATION_PATH=/Users/hitanshughadai/RideOS-AI/apps/mobile"
export "FLUTTER_FRAMEWORK_SWIFT_PACKAGE_PATH=/Users/hitanshughadai/RideOS-AI/apps/mobile/macos/Flutter/ephemeral/Packages/.packages/FlutterFramework"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=2.4.0"
export "FLUTTER_BUILD_NUMBER=2400"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
