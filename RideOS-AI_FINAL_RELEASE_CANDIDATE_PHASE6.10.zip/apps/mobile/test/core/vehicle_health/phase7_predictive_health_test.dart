import 'package:flutter_test/flutter_test.dart';
import 'package:rideos_mobile/core/vehicle_health/services/predictive_vehicle_health_engine.dart';

void main() {
  group('Phase 7 - Predictive Vehicle Health Engine Tests', () {
    late PredictiveVehicleHealthEngine engine;

    setUp(() {
      engine = PredictiveVehicleHealthEngine();
    });

    test('Evaluates overall health report and marks data classification accurately', () {
      final offlineReport = engine.evaluateHealthReport(isBleConnected: false);
      expect(offlineReport.dataClassification, equals('HARDWARE_NOT_CONNECTED'));

      final liveReport = engine.evaluateHealthReport(isBleConnected: true);
      expect(liveReport.dataClassification, equals('LIVE BLE VEHICLE'));
    });

    test('Generates predictive recommendations when health parameters deviate', () {
      final report = engine.evaluateHealthReport();
      expect(report.subsystems.every((s) => s.healthScore >= 0 && s.healthScore <= 100), isTrue);
      expect(report.overallStatus, isNotEmpty);
    });
  });
}
